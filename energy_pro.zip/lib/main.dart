import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(EnergyProApp());
}

class EnergyProApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ENERGY PRO',
      theme: ThemeData(primarySwatch: Colors.red),
      home: SensitivityHome(),
    );
  }
}

class SensitivityHome extends StatefulWidget {
  @override
  _SensitivityHomeState createState() => _SensitivityHomeState();
}

class _SensitivityHomeState extends State<SensitivityHome> {
  final TextEditingController _deviceController = TextEditingController();
  Map<String, int> _sensitivity = {};
  int _dpi = 0;

  void _generateSensitivity() {
    final rand = Random();
    setState(() {
      _sensitivity = {
        "General": rand.nextInt(200),
        "Red Dot": rand.nextInt(200),
        "2x Scope": rand.nextInt(200),
        "4x Scope": rand.nextInt(200),
        "AWM Scope": rand.nextInt(200),
        "Free Look": rand.nextInt(200),
      };
      _dpi = [360, 400, 480, 560, 600][rand.nextInt(5)];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("ENERGY PRO Sensitivity Generator")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _deviceController,
              decoration: InputDecoration(
                labelText: "Enter Device Name",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _generateSensitivity,
              child: Text("Generate Settings"),
            ),
            SizedBox(height: 20),
            if (_sensitivity.isNotEmpty) ...[
              Text(
                "Device: ${_deviceController.text.isEmpty ? "Unknown" : _deviceController.text}",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              ..._sensitivity.entries.map(
                (e) => Text("${e.key}: ${e.value}", style: TextStyle(fontSize: 16)),
              ),
              SizedBox(height: 10),
              Text("Recommended DPI: $_dpi", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ]
          ],
        ),
      ),
    );
  }
}
